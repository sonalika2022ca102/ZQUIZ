let questions = [
    {
        numb:1,
        question:"DSA stands for",
        answer:"Data Structures and Algorithms",
        options: [
            "hi",
            "how",
            "are",
            "Data Structures and Algorithms"
        ]
    },
    {
        numb:2,
        question:"Who invented it?",
        answer:"ijk",
        options: [
            "abc",
            "xyz",
            "mno",
            "ijk"
        ]
    },

    {
        numb:3,
        question:"What?",
        answer:"blh",
        options: [
            "kjk",
            "blh",
            "oah",
            "bgf"
        ]
    },

    {
        numb:4,
        question:"Why?",
        answer:"wrf",
        options: [
            "fsdh",
            "dfdh",
            "wrf",
            "hms"
        ]
    },
    {
        numb:5,
        question:"When?",
        answer:"trf",
        options: [
            "trf",
            "bgt",
            "swe",
            "Dgs"
        ]
    },

    {
        numb:6,
        question:"Where?",
        answer:"dats",
        options: [
            "blah",
            "dats",
            "blah",
            "uct"
        ]
    },
    {
        numb:7,
        question:"Who?",
        answer:"gtrd",
        options: [
            "bgt",
            "gted",
            "gted",
            "gtrd"
        ]
    },
    {
        numb:8,
        question:"Which?",
        answer:"lgms",
        options: [
            "blh",
            "bdah",
            "ddsh",
            "lgms"
        ]
    },
    {
        numb:9,
        question:"With?",
        answer:"thms",
        options: [
            "bdah",
            "bruh",
            "sesh",
            "thms"
        ]
    },
    {
        numb:10,
        question:"What else?",
        answer:"ures",
        options: [
            "fre",
            "ures",
            "wdwf",
            "gor"
        ]
    },

];